package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Optional;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = null;
        try {
            sc = new Scanner(new FileReader(new File("C:\\Users\\EosReign\\Downloads\\Sber.txt")));
            City city = new City();
            while(sc.hasNextLine()) {
                String[] buffer = sc.nextLine().split(";");
                city.setName(buffer[1]);
                city.setDistrict(buffer[2]);
                city.setRegion(buffer[3]);
                city.setPopulation(Integer.valueOf(buffer[4]));
                city.setFoundation(buffer.length == 6 ? buffer[5] : "Unknown");
                System.out.println(buffer[0] + ": " + city);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            sc.close();
        }

    }
}