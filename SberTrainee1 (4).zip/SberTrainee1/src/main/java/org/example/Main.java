package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner sc = null;
        try {
            sc = new Scanner(new FileReader(new File("C:\\Users\\EosReign\\Downloads\\Sber.txt")));
            List<City> list = new ArrayList<>();
            //City[] arr = new City[1200];

            while(sc.hasNextLine()) {
                City city = new City();
                String[] buffer = sc.nextLine().split(";");
                city.setName(buffer[1]);
                city.setDistrict(buffer[2]);
                city.setRegion(buffer[3]);
                city.setPopulation(Integer.valueOf(buffer[4]));
                city.setFoundation(buffer.length == 6 ? buffer[5] : "Unknown");
                list.add(city);
            }
            /*
            for (int i = 0; sc.hasNext(); i++) {
                City city = new City();
                String[] buffer = sc.nextLine().split(";");
                city.setName(buffer[1]);
                city.setDistrict(buffer[2]);
                city.setRegion(buffer[3]);
                city.setPopulation(Integer.valueOf(buffer[4]));
                city.setFoundation(buffer.length == 6 ? buffer[5] : "Unknown");
                arr[i] = city;
            }

             */

            getCityCountByRegion(list).stream().forEach(System.out::println);
            //System.out.println(getCityByMaxPopulation(arr));
            //sortByName(list).stream().forEach(System.out::println);
            //sortByRegionAndName(arr).stream().forEach(System.out::println);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            sc.close();
        }
    }

    public static List<City> sortByName(List<City> arr) {
        arr = arr.stream().sorted(Comparator.comparing(City::getName))
                .collect(Collectors.toList());
        return arr;
    }

    public static List<City> sortByRegionAndName(List<City> arr) {
       arr = arr.stream().sorted(Comparator.comparing(City::getRegion).thenComparing(City::getName))
               .collect(Collectors.toList());
        return arr;
    }

    public static String getCityByMaxPopulation(City[] arr) {
        int max = Integer.MIN_VALUE;
        int id = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == null) {
                break;
            }
            id = max > arr[i].getPopulation() ? id : i;
            max = max > arr[i].getPopulation() ? max : arr[i].getPopulation();
        }
        return String.valueOf(id + ": " + max);
    }

    public static List<String> getCityCountByRegion(List<City> list) {
        list = list.stream().sorted(Comparator.comparing(City::getDistrict)).collect(Collectors.toList());
        List<String> output = new ArrayList<>();
        String buffer = "";
        int counter = 1;
        for (int i = 0; i < list.size(); i++) {
            if (i == 0) {
                buffer = list.get(i).getDistrict();
            } else if (list.get(i).getDistrict().equals(buffer)) {
                counter++;
            } else {
                output.add(new String(buffer + " - " + counter));
                buffer = list.get(i).getDistrict();
                counter = 1;
            }
        }
        return output;
    }
}