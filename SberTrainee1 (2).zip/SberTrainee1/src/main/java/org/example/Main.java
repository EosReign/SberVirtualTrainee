package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner sc = null;
        try {
            sc = new Scanner(new FileReader(new File("C:\\Users\\EosReign\\Downloads\\Sber.txt")));
            List<City> arr = new ArrayList<>();
            while(sc.hasNextLine()) {
                City city = new City();
                String[] buffer = sc.nextLine().split(";");
                city.setName(buffer[1]);
                city.setDistrict(buffer[2]);
                city.setRegion(buffer[3]);
                city.setPopulation(Integer.valueOf(buffer[4]));
                city.setFoundation(buffer.length == 6 ? buffer[5] : "Unknown");
                arr.add(city);
            }

            sortByName(arr).stream().forEach(System.out::println);
            //sortByRegionAndName(arr).stream().forEach(System.out::println);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            sc.close();
        }
    }

    public static List<City> sortByName(List<City> arr) {
        arr = arr.stream().sorted(Comparator.comparing(City::getName))
                .collect(Collectors.toList());
        return arr;
    }

    public static List<City> sortByRegionAndName(List<City> arr) {
       arr = arr.stream().sorted(Comparator.comparing(City::getRegion).thenComparing(City::getName))
               .collect(Collectors.toList());
        return arr;
    }
}